require("@nomiclabs/hardhat-waffle");
/**
 * @type import('hardhat/config').HardhatUserConfig
 */
module.exports = {
  solidity: "0.8.4",
  networks:{
    rinkeby:{
      url:'https://eth-rinkeby.alchemyapi.io/v2/M1Rr5ClByciUDBeyWbgzkiJtq39GbG2W',
      accounts:[
        'a6fd562d41f6c7b979008e43519b0069bf93ecdda0a957d97e636800beec2e28'
      ],
    }
  },
}
